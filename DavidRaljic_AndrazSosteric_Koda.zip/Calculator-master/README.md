# Calculator
Za uporabo aplikacije dvakrat kliknite na Calculator.exe

MyForm.cpp -> vsebuje main funkcijo

MyForm.h -> vsebuje izgled aplikacije in funkcionalnost elementov

FileHandler.h -> skrbi za delo z datotekami

Data.h -> Povezuje MyForm z datotekami, ki resijo racune

Calculate.h -> klasicni racuni

NumConversion.h -> pretvarjanje stevilskih sistemov

LogicalOperation.h -> Logicne operacije

resource.h, resource1.h, resource2.h, resource3.h, calculator.rc pomozne datoteke za ikono

Wwalczyszyn-Android-Style-Honeycomb-Calculator (Vir: https://iconarchive.com/show/android-style-honeycomb-icons-by-wwalczyszyn/Calculator-icon.html, dostop 14. 1. 2023, avtor: https://iconarchive.com/artist/wwalczyszyn.html; licenca: https://creativecommons.org/licenses/by-nc-nd/4.0/)
